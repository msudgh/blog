# The Node Beginner Persian Book
